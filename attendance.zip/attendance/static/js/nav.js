$(function(){
    $("#nav-placeholder").load("nav1.html");
})